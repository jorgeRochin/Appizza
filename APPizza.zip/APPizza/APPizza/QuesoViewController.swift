//
//  QuesoViewController.swift
//  APPizza
//
//  Created by Jorge Rochín. on 17/11/16.
//  Copyright © 2016 Jorge Rochín. All rights reserved.
//

import UIKit

class QuesoViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {

    @IBOutlet weak var pickerQueso: UIPickerView!
    
    var quesos = ["Selecciona Queso","Mozarela", "Cheddar", "Parmesano", "Sin queso"]
    var elTamaño:String=""
    var laMasa:String=""
    var elQueso:String=""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.pickerQueso.delegate = self
        self.pickerQueso.dataSource = self
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return quesos.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return quesos[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        elQueso = quesos[row]
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let sigVista = segue.destination as! IngredientesViewController
        sigVista.elTamaño = elTamaño
        sigVista.laMasa = laMasa
        sigVista.elQueso = elQueso
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
