//
//  PedidoViewController.swift
//  APPizza
//
//  Created by Jorge Rochín. on 17/11/16.
//  Copyright © 2016 Jorge Rochín. All rights reserved.
//

import UIKit

class PedidoViewController: UIViewController {

    @IBOutlet weak var tamaño: UILabel!
    @IBOutlet weak var masa: UILabel!
    @IBOutlet weak var queso: UILabel!
    @IBOutlet weak var ingredientes: UITextField!
    
    var pizza = Pizza()
    var elTamaño:String=""
    var laMasa:String=""
    var elQueso:String=""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        tamaño.text = elTamaño
        masa.text = laMasa
        queso.text = elQueso
        ingredientes.text = pizza.stringIngredientes()
    }
    
    @IBAction func confirmar(_ sender: Any) {
        if elTamaño == "" {
            mostrarAlertaCon(mensaje: "No ha seleccionado el tamaño")
            return
        }
        
        if laMasa == "" {
            mostrarAlertaCon(mensaje: "No ha seleccionado tipo de masa")
            return
        }
        
        if elQueso == "" {
            mostrarAlertaCon(mensaje: "No ha seleccionado tipo de queso.\nSi no debea un tipo de queso, favor de elegir la opcion \"Sin queso\"")
            return
        }
        
        if pizza.ingredientes == nil || (pizza.ingredientes?.count)! <= 0 {
            mostrarAlertaCon(mensaje: "No ha seleccionado ningún ingrediente")
            return
        }
        
        mostrarAlertaCon(mensaje: "Tú pedido estará listo en un momento")
    }
    
    func mostrarAlertaCon(mensaje:String) {
        let aceptar = UIAlertAction(title: "OK", style: .default, handler: nil)
        let alerta:UIAlertController = UIAlertController(title: "Aviso", message: mensaje, preferredStyle: .alert)
        alerta.addAction(aceptar)
        self.present(alerta, animated: true, completion: nil)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
