//
//  Pizza.swift
//  APPizza
//
//  Created by Jorge Rochín. on 17/11/16.
//  Copyright © 2016 Jorge Rochín. All rights reserved.
//

import Foundation

class Pizza {
    
	static let aIngredientes = ["Jamón", "Pepperoni", "Pavo" , "Salchicha", "Aceituna", "Cebolla", "Pimiento", "Piña", "Anchoa", "Camarón", "Pulpo", "Chorizo"]
    
    var ingredientes: [String]? = [String]()

    class func obtenerIngrediente() -> [String] {
        return aIngredientes
    }
    
    func quitarIngrediente(ingrediente:String){
        if (self.ingredientes?.contains(ingrediente)) != nil {
            let index = self.ingredientes?.index(of: ingrediente)
            self.ingredientes?.remove(at: index!)
        }
    }
    
    func stringIngredientes() -> String {
        var ind:String = ""
        for i in ingredientes! {
            ind.append("\(i), ")
        }
        return ind.substring(to: ind.endIndex)
    }
    
}
