//
//  IngredientesViewController.swift
//  APPizza
//
//  Created by Jorge Rochín. on 17/11/16.
//  Copyright © 2016 Jorge Rochín. All rights reserved.
//

import UIKit

class IngredientesViewController: UIViewController {

    @IBOutlet weak var botonSiguiente: UIButton!
    var pizza = Pizza()
    var elTamaño:String=""
    var laMasa:String=""
    var elQueso:String=""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        botonSiguiente.isEnabled=false
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func jamon(_ sender: UIButton) {
        selecIngrediente(boton: sender, posicion: 0)
    }
    
    @IBAction func pepperoni(_ sender: UIButton) {
        selecIngrediente(boton: sender, posicion: 1)
    }
    
    @IBAction func pavo(_ sender: UIButton) {
        selecIngrediente(boton: sender, posicion: 2)
    }
    
    @IBAction func salchicha(_ sender: UIButton) {
        selecIngrediente(boton: sender, posicion: 3)
    }
    
    @IBAction func aceituna(_ sender: UIButton) {
        selecIngrediente(boton: sender, posicion: 4)
    }

    @IBAction func cebolla(_ sender: UIButton) {
        selecIngrediente(boton: sender, posicion: 5)
    }
    
    @IBAction func pimiento(_ sender: UIButton) {
        selecIngrediente(boton: sender, posicion: 6)
    }
    
    @IBAction func piña(_ sender: UIButton) {
        selecIngrediente(boton: sender, posicion: 7)
    }
    
    @IBAction func anchoa(_ sender: UIButton) {
        selecIngrediente(boton: sender, posicion: 8)
    }
    
    @IBAction func camaron(_ sender: UIButton) {
        selecIngrediente(boton: sender, posicion: 9)
    }
    
    @IBAction func pulpo(_ sender: UIButton) {
        selecIngrediente(boton: sender, posicion: 10)
    }
    
    @IBAction func chorizo(_ sender: UIButton) {
        selecIngrediente(boton: sender, posicion: 11)
    }
    
    func selecIngrediente(boton:UIButton, posicion:Int) {
        if boton.isSelected {
            pizza.quitarIngrediente(ingrediente: Pizza.obtenerIngrediente()[posicion])
            boton.isSelected = false
            if (pizza.ingredientes?.isEmpty)! {
                botonSiguiente.isEnabled = false
            }
        } else {
            if (pizza.ingredientes?.endIndex)! < 5 {
                pizza.ingredientes?.append(Pizza.obtenerIngrediente()[posicion])
                boton.isSelected = true
                botonSiguiente.isEnabled = true
            } 
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let sigVista = segue.destination as! PedidoViewController
        sigVista.pizza = self.pizza
        sigVista.elTamaño = elTamaño
        sigVista.laMasa = laMasa
        sigVista.elQueso = elQueso
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
